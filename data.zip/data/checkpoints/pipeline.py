"""
Kilbrack work order processing pipeline.

Usage:   python pipeline.py config_cmms.json

Everything that changes between data sources (file path, separator, column names, date formats, category
mappings, thresholds) lives in the JSON config. The code below should not need editing for a new export.
"""
import difflib
import json
import logging
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd

log = logging.getLogger("pipeline")

REQUIRED = ["wo_id", "asset_id", "wo_type", "priority", "date_raised", "date_closed", "status",
            "labour_hours", "parts_cost_eur", "technician", "description", "last_modified"]


# ------------------------------------------------------------------ small helpers (each one testable on its own)
def to_number(series, decimal="."):
    """Text to float. Handles '€1,250.00' (decimal='.') and '1.250,00' (decimal=',')."""
    s = series.astype("string").str.replace("€", "", regex=False).str.replace(" ", "", regex=False)
    if decimal == ",":
        s = s.str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
    else:
        s = s.str.replace(",", "", regex=False)
    return pd.to_numeric(s, errors="coerce")


def parse_dates(series, formats):
    """Try each format in turn; values that fit none stay NaT."""
    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    for fmt in formats:
        result = result.fillna(pd.to_datetime(series, format=fmt, errors="coerce"))
    return result


def normalise_asset_id(series):
    s = series.astype("string").str.strip().str.upper()
    return s.str.replace(r"^([A-Z]+)-?(\d+)$", r"\1-\2", regex=True)


def normalise_name(name):
    if pd.isna(name):
        return name
    text = unicodedata.normalize("NFKD", str(name)).encode("ascii", "ignore").decode()
    text = text.replace("'", "").replace(".", " ")
    if "," in text:
        last, first = [p.strip() for p in text.split(",", 1)]
        text = f"{first} {last}"
    return " ".join(text.lower().split())


# ------------------------------------------------------------------ pipeline steps
def load_work_orders(cfg):
    src = cfg["source"]
    df = pd.read_csv(src["path"], sep=src.get("sep", ","), dtype=str, keep_default_na=False)
    log.info(f"Loaded {len(df)} rows from {src['path']}")
    df = df.rename(columns=src.get("column_map", {}))
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Columns missing after renaming: {missing}. Check source.column_map in the config.")
    df = df[REQUIRED].replace({v: np.nan for v in cfg["na_values"]})
    return df


def clean_work_orders(df, cfg):
    src = cfg["source"]
    df = df.copy()
    df["asset_id"] = normalise_asset_id(df["asset_id"])
    df["status"] = df["status"].str.strip().str.title()

    # Categories: anything unmapped stops the run, with the offending values in the message
    raw_types = df["wo_type"].str.strip().str.upper()
    df["wo_type"] = raw_types.map(cfg["type_map"])
    unmapped = sorted(raw_types[df["wo_type"].isna()].dropna().unique())
    if unmapped:
        raise ValueError(f"Unmapped work order types {unmapped}. Add them to type_map in the config.")

    p = df["priority"].astype("string").str.strip().str.upper()
    p = p.str.replace("P", "", regex=False).str.replace("URGENT", "1", regex=False)
    df["priority"] = pd.to_numeric(p, errors="coerce").astype("Int64")

    for col in ["labour_hours", "parts_cost_eur"]:
        df[col] = to_number(df[col], src.get("decimal", "."))
    df["hours_missing"] = df["labour_hours"].isna()

    for col in ["date_raised", "date_closed"]:
        df[col] = parse_dates(df[col], src["date_formats"])
    df["last_modified"] = parse_dates(df["last_modified"], src["modified_formats"])
    if df["date_raised"].isna().any():
        bad = df.loc[df["date_raised"].isna(), "wo_id"].tolist()[:5]
        raise ValueError(f"date_raised did not parse for e.g. {bad}. Check source.date_formats in the config.")

    # Technicians: approved mapping first, fuzzy match against the staff list as a fallback
    approved = pd.read_csv(cfg["technician_map_file"])
    name_map = dict(zip(approved["tech_norm"], approved["technician"]))
    staff_by_norm = {normalise_name(s): s for s in cfg["staff"]}
    df["technician_raw"] = df["technician"]
    norm = df["technician"].apply(normalise_name)

    def match(n):
        if pd.isna(n):
            return np.nan
        if n in name_map:
            return name_map[n]
        hit = difflib.get_close_matches(n, staff_by_norm.keys(), n=1, cutoff=0.85)
        return staff_by_norm[hit[0]] if hit else np.nan

    df["technician"] = norm.apply(match)
    unknown = sorted(df.loc[df["technician"].isna() & df["technician_raw"].notna(), "technician_raw"].unique())
    if unknown:
        log.warning(f"Technician names needing a human: {unknown}")
    return df


def dedupe_work_orders(df):
    n0 = len(df)
    df = df.drop_duplicates()
    n1 = len(df)
    # Same work order exported more than once: keep the most recently modified version
    df = df.sort_values("last_modified").drop_duplicates(subset="wo_id", keep="last")
    log.info(f"Dedup: {n0 - n1} exact duplicates, {n1 - len(df)} older versions removed, {len(df)} work orders")
    if not df["wo_id"].is_unique:
        raise ValueError("wo_id still not unique after dedup")
    return df.sort_values("date_raised").reset_index(drop=True)


def join_assets(df, cfg):
    reg = pd.read_csv(cfg["asset_register_file"])
    decom = pd.read_excel(cfg["decommissioned_file"], sheet_name="Decommissioned")
    in_service = reg[["asset_id", "asset_type", "site", "criticality"]].assign(asset_status="In Service")
    retired = (decom.rename(columns={"Asset ID": "asset_id", "Asset Type": "asset_type", "Site": "site",
                                     "Criticality": "criticality"})
                    [["asset_id", "asset_type", "site", "criticality"]].assign(asset_status="Decommissioned"))
    assets = pd.concat([in_service, retired], ignore_index=True)
    n = len(df)
    out = df.merge(assets, on="asset_id", how="left", validate="many_to_one", indicator=True)
    out.loc[out["_merge"] == "left_only", "asset_status"] = "Unknown asset"
    assert len(out) == n, "Join changed the number of rows"
    return out.drop(columns="_merge")


def validate(df, cfg):
    t = cfg["thresholds"]
    as_of = pd.Timestamp(t["as_of"])
    rules = {
        "closed_before_raised": df["date_closed"] < df["date_raised"],
        "negative_hours": df["labour_hours"] < 0,
        "implausible_hours": df["labour_hours"] > t["max_hours"],
        "closed_without_date": (df["status"] == "Closed") & df["date_closed"].isna(),
        "unknown_asset": df["asset_status"] == "Unknown asset",
        "implausible_cost": df["parts_cost_eur"] > t["max_cost"],
        "negative_cost": df["parts_cost_eur"] < 0,
        "missing_hours": df["labour_hours"].isna(),
        "missing_cost": df["parts_cost_eur"].isna(),
        "open_too_long": (df["status"] != "Closed") & ((as_of - df["date_raised"]).dt.days > t["open_days"]),
    }
    flags = pd.DataFrame(rules)
    df = df.copy()
    df["dq_issues"] = flags.apply(lambda r: ", ".join(r.index[r]), axis=1)
    df["dq_error"] = flags[cfg["error_rules"]].any(axis=1)
    report = pd.DataFrame({"rule": flags.columns,
                           "severity": ["error" if r in cfg["error_rules"] else "warning" for r in flags.columns],
                           "rows_flagged": flags.sum().values})
    report["pct"] = (report["rows_flagged"] / len(df) * 100).round(2)
    for _, r in report[report["rows_flagged"] > 0].iterrows():
        (log.warning if r["severity"] == "error" else log.info)(f"Rule {r['rule']}: {r['rows_flagged']} rows")
    return df, report


def save_outputs(df, report, out_dir):
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / "work_orders_clean.csv", index=False)
    df[~df["dq_error"]].to_csv(out_dir / "work_orders_kpi_ready.csv", index=False)
    df[df["dq_issues"] != ""].to_csv(out_dir / "dq_issues.csv", index=False)
    report.to_csv(out_dir / "dq_report.csv", index=False)
    log.info(f"Outputs written to {out_dir}")


def run_pipeline(cfg):
    out_dir = Path(cfg["output_dir"]) / cfg["run_name"]
    out_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-7s %(message)s", force=True,
                        handlers=[logging.FileHandler(out_dir / "pipeline.log", mode="w"),
                                  logging.StreamHandler(sys.stdout)])
    log.info(f"Run '{cfg['run_name']}' started")
    df = load_work_orders(cfg)
    df = clean_work_orders(df, cfg)
    df = dedupe_work_orders(df)
    df = join_assets(df, cfg)
    df, report = validate(df, cfg)
    save_outputs(df, report, out_dir)
    summary = {"rows_out": len(df), "errors": int(df["dq_error"].sum()), "output_dir": str(out_dir)}
    log.info(f"Finished: {summary}")
    return summary


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python pipeline.py <config.json>")
    with open(sys.argv[1], encoding="utf-8") as f:
        config = json.load(f)
    run_pipeline(config)
